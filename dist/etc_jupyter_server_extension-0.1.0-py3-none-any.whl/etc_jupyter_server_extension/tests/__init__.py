"""Python unit tests for etc_jupyter_server_extension."""
