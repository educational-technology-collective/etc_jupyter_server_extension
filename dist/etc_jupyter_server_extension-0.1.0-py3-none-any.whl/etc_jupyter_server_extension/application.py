from .handlers import RouteHandler
from jupyter_server.extension.application import ExtensionApp
from traitlets import Bool


class ETCJupyterServerExtensionApp(ExtensionApp):

    name = "etc_jupyter_server_extension"

    test = Bool(False, config=True)

    def initialize_settings(self):
        self.log.info(f"Config {self.config}")

    def initialize_handlers(self):
        handlers = [(r'/etc-jupyter-server-extension/(.*)', RouteHandler)]
        self.handlers.extend(handlers)
