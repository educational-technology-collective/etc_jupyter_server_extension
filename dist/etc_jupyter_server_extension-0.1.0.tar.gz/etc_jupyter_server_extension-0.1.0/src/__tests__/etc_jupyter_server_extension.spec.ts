/**
 * Example of [Jest](https://jestjs.io/docs/getting-started) unit tests
 */

describe('@educational-technology-collective/etc_jupyter_server_extension', () => {
  it('should be tested', () => {
    expect(1 + 1).toEqual(2);
  });
});
